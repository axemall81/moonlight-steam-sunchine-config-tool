const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const cors = require('cors');
const { exec } = require('child_process');
const app = express();
const port = 3000;
const hostname = '0.0.0.0'; // Serve on all network interfaces

// Sunshine configuration paths
const sunshineConfigPath = path.join(__dirname, 'sunshine_games.json');
const sunshineApiUrl = 'http://localhost:47990/api/apps';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// Multer for image uploads
const upload = multer({ dest: 'public/uploads/' });

// Ensure Sunshine config file exists
if (!fs.existsSync(sunshineConfigPath)) {
  fs.writeFileSync(sunshineConfigPath, JSON.stringify([]));
}

// Add Steam Game to Sunshine
app.post('/api/add-steam-game', upload.single('steamImage'), (req, res) => {
  const { steamCommand, steamAppName } = req.body;
  if (!steamCommand || !steamAppName) {
    return res.status(400).send('Missing game details.');
  }

  const newGame = {
    name: steamAppName,
    cmd: steamCommand,
    'image-path': req.file ? `/uploads/${req.file.filename}` : '',
  };

  const games = JSON.parse(fs.readFileSync(sunshineConfigPath));
  games.push(newGame);
  fs.writeFileSync(sunshineConfigPath, JSON.stringify(games, null, 2));

  res.send('Steam game added successfully!');
});

// Add Executable Game to Sunshine
app.post('/api/add-exe-game', upload.single('exeImage'), (req, res) => {
  const { exePath, exeName } = req.body;
  if (!exePath || !exeName) {
    return res.status(400).send('Missing game details.');
  }

  const newGame = {
    name: exeName,
    cmd: exePath,
    'image-path': req.file ? `/uploads/${req.file.filename}` : '',
  };

  const games = JSON.parse(fs.readFileSync(sunshineConfigPath));
  games.push(newGame);
  fs.writeFileSync(sunshineConfigPath, JSON.stringify(games, null, 2));

  res.send('Executable game added successfully!');
});

// Get all games from Sunshine
app.get('/api/games', (req, res) => {
  const games = JSON.parse(fs.readFileSync(sunshineConfigPath));
  res.json(games);
});

// Remove a game
app.post('/api/remove-game', (req, res) => {
  const { gameName } = req.body;
  let games = JSON.parse(fs.readFileSync(sunshineConfigPath));
  const updatedGames = games.filter(game => game.name !== gameName);

  if (games.length === updatedGames.length) {
    return res.status(404).send('Game not found.');
  }

  fs.writeFileSync(sunshineConfigPath, JSON.stringify(updatedGames, null, 2));
  res.send('Game removed successfully.');
});

// Start server on all interfaces
app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
